# 耳机商城指南

## 接口文档

apidoc.txt

## 前端

```bash
cd ./client
yarn
yarn run dev
```

## 开启后端服务

```shell
cd ./server
npm i
node index.js
```
